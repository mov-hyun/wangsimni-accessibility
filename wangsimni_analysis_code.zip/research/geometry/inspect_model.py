"""Decode public S-MAP geometry. Raw XY is horizontal; -Z is elevation.
Outputs retain raw coordinates, without fitting a scale or claiming routes.
"""
from pathlib import Path
import sys, json, struct, csv, io
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/deep_dive/.deps'))
import DracoPy

def load():
    raw=(ROOT/'research/sources/wangsimni_smap.glb').read_bytes()
    size=struct.unpack_from('<I',raw,12)[0]
    j=json.loads(raw[20:20+size]); blob=raw[28+size:]
    return j,blob

def main():
    j,blob=load(); out={}; rows=[]; levels=[]
    print('material_count',len(j.get('materials',[])), 'image_count',len(j.get('images',[])))
    for n in j['nodes']:
        if 'mesh' not in n: continue
        for pi,p in enumerate(j['meshes'][n['mesh']]['primitives']):
            v=j['bufferViews'][p['extensions']['KHR_draco_mesh_compression']['bufferView']]
            start=v.get('byteOffset',0)
            m=DracoPy.decode(blob[start:start+v['byteLength']]); pts=m.points; faces=m.faces
            key=f"{n['name']}__{pi}"
            out[key+'_points']=pts; out[key+'_faces']=faces
            if m.tex_coord is not None: out[key+'_uv']=m.tex_coord
            rows.append(dict(key=key,material=p.get('material'),vertices=len(pts),faces=len(faces),
                **{f'{axis}_{t}':float(getattr(pts[:,i],t)()) for i,axis in enumerate('xyz') for t in ['min','max']}))
            tri=pts[faces]; normal=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]); area=np.linalg.norm(normal,axis=1)/2
            horizontal=np.ptp(tri[:,:,2],axis=1)<0.025
            z=np.round(tri[:,:,2].mean(axis=1),2)
            for zz in np.unique(z[horizontal]):
                mask=horizontal&(z==zz); a=area[mask].sum()
                if a>2: levels.append(dict(key=key,z=float(zz),area=float(a),faces=int(mask.sum())))
    np.savez_compressed(HERE/'mesh_arrays.npz',**out)
    for name,records in [('primitives.csv',rows),('horizontal_surfaces.csv',levels)]:
        with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=records[0]);w.writeheader();w.writerows(records)
    for i,im in enumerate(j.get('images',[])):
        v=j['bufferViews'][im['bufferView']]; start=v.get('byteOffset',0)
        pic=Image.open(io.BytesIO(blob[start:start+v['byteLength']]))
        pic.save(HERE/f'texture_{i}.png')
    print('decoded',len(rows),'primitives')
    for floor in ['B1','B2','B4','B5']:
        top=sorted([r for r in levels if r['key'].startswith(floor+'__')],key=lambda r:r['area'],reverse=True)[:8]
        print(floor,top)

if __name__=='__main__': main()
