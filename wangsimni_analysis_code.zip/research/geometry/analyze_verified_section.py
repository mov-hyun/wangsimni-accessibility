"""Model-based route comparison limited to the checked B4-B5 section.

Uses floor triangles and wall cross-sections, manually reviewed facility approaches,
and eight fixed platform points derived from modeled wheelchair boarding markings.
No whole-station reachability, observed walking time, or failure probability claim.
"""
from pathlib import Path
import csv,json,math,heapq,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import distance_transform_edt
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
Z=np.load(HERE/'mesh_arrays.npz')
ANGLE=math.radians(-27.68)
R=np.array([[math.cos(ANGLE),math.sin(ANGLE)],[-math.sin(ANGLE),math.cos(ANGLE)]])
# Port positions are approach points reviewed against tactile paving and floor openings.
# They are not survey coordinates of elevator door thresholds.
PORTS={
 'J2':('B4',[4.5,-12.5],'2호선 환승통로 합류 후 대합실 기준점'),
 'E3_4':('B4',[23.8,-21.0],'5호선 EL3 B4 접근점'),
 'E3_5':('B5',[22.3,-25.1],'5호선 EL3 B5 접근점'),
 'E2_4':('B4',[23.8,-51.0],'5호선 EL2 B4 접근점'),
 'E2_5':('B5',[23.8,-51.0],'5호선 EL2 B5 접근점'),
 'SNW_4':('B4',[19.2,-21.4],'마장 방면 승강장 서측 계단 상단 접근점'),
 'SNW_5':('B5',[6.6,-21.4],'마장 방면 승강장 서측 계단 하단 접근점'),
 'SNE_4':('B4',[29.4,-21.4],'마장 방면 승강장 동측 계단 상단 접근점'),
 'SNE_5':('B5',[41.2,-21.4],'마장 방면 승강장 동측 계단 하단 접근점'),
 'SSW_4':('B4',[19.2,-50.9],'행당 방면 승강장 서측 계단 상단 접근점'),
 'SSW_5':('B5',[6.6,-50.9],'행당 방면 승강장 서측 계단 하단 접근점'),
 'SSE_4':('B4',[29.4,-50.9],'행당 방면 승강장 동측 계단 상단 접근점'),
 'SSE_5':('B5',[41.2,-50.9],'행당 방면 승강장 동측 계단 하단 접근점'),
}
# Wheelchair floor symbols in the source mesh occur as eight 4-vertex quads.
markings=Z['B5__114_points'].reshape(-1,4,3).mean(axis=1)
targets=[]
for i,p in enumerate(markings):
    q=R@p[:2]; platform='M' if q[1]>-36 else 'H'
    q[1]+=1 if platform=='M' else -1  # one model metre into platform from symbol
    targets.append((platform,float(q[0]),q.tolist(),i))
for platform in ['M','H']:
    for num,(_,_,q,source_quad) in enumerate(sorted(t for t in targets if t[0]==platform),1):
        PORTS[f'{platform}{num}']=('B5',q,f'{platform} 승강장 모델 승차표시 {source_quad}에서 안쪽 1m 기준점')
VERTICAL=[('E2_4','E2_5','EL','0103-813'),('E3_4','E3_5','EL','0103-814')]
VERTICAL += [(s+'_4',s+'_5','STAIR',s) for s in ['SNW','SNE','SSW','SSE']]

def jsonwrite(name,data):
    (HERE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def csvwrite(name,rows):
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

def build_floor(floor,res):
    bounds=(-10,-60,55,5) if floor=='B4' else (-35,-60,140,-10)
    x0,y0,x1,y1=bounds;w=round((x1-x0)/res)+1;h=round((y1-y0)/res)+1
    img=Image.new('1',(w,h));d=ImageDraw.Draw(img)
    def pixel(p):
        q=R@p[:2];return ((q[0]-x0)/res,(y1-q[1])/res)
    for pi in ([85,86,87] if floor=='B4' else [112]):
        key=f'{floor}__{pi}';p=Z[key+'_points'];f=Z[key+'_faces']
        for t in p[f]: d.polygon([pixel(v) for v in t],fill=1)
    # Cross-section 0.6 m above floor identifies walls and columns. Keep a 0.2 m
    # geometric clearance from them; this is not a wheelchair-width certification.
    floor_z=-5.81189 if floor=='B4' else -1.41
    section=floor_z-.6
    for key in Z.files:
        if not key.startswith(floor+'__') or not key.endswith('_points'):continue
        p=Z[key];tris=p[Z[key[:-7]+'_faces']]
        for t in tris:
            if not(t[:,2].min()<section<t[:,2].max()):continue
            inter=[]
            for a,b in zip(t,np.roll(t,-1,axis=0)):
                if (a[2]-section)*(b[2]-section)<0:inter.append(a+(b-a)*((section-a[2])/(b[2]-a[2])))
            if len(inter)==2:d.line([pixel(v) for v in inter],fill=0,width=1)
    mask=np.array(img,dtype=bool)
    clearance=distance_transform_edt(mask)*res
    mask &= clearance>=.2
    ids=np.full(mask.shape,-1,dtype=np.int32);ids[mask]=np.arange(mask.sum(),dtype=np.int32)
    # 32 directed movements (primitive integer vectors with maximum component 3).
    # Intermediate samples prevent jumping through walls or cutting blocked corners.
    rr=[];cc=[];ww=[]
    for dy in range(-3,4):
      for dx in range(-3,4):
        if not(dx or dy) or math.gcd(abs(dx),abs(dy))!=1:continue
        if dx*dx+dy*dy>13:continue
        ys=slice(max(0,-dy),min(h,h-dy));xs=slice(max(0,-dx),min(w,w-dx))
        yd=slice(max(0,dy),min(h,h+dy));xd=slice(max(0,dx),min(w,w+dx))
        ok=mask[ys,xs]&mask[yd,xd]
        y0i=ys.start;x0i=xs.start
        # Conservative supercover: both surrounding cells at each half-cell step.
        for t in np.linspace(0,1,2*max(abs(dx),abs(dy))+1)[1:-1]:
          sy=dy*t;sx=dx*t
          for oy in {math.floor(sy),math.ceil(sy)}:
            for ox in {math.floor(sx),math.ceil(sx)}:
              ok &= mask[y0i+oy:y0i+oy+ok.shape[0],x0i+ox:x0i+ox+ok.shape[1]]
        if ok.any():
            rr.append(ids[ys,xs][ok]);cc.append(ids[yd,xd][ok]);ww.append(np.full(ok.sum(),res*math.hypot(dx,dy)))
    graph=coo_matrix((np.concatenate(ww),(np.concatenate(rr),np.concatenate(cc))),shape=(int(mask.sum()),)*2).tocsr()
    lookup={};snaps=[]
    free=np.column_stack(np.nonzero(mask))
    for name,(fl,q,label) in PORTS.items():
        if fl!=floor:continue
        py=(y1-q[1])/res;px=(q[0]-x0)/res
        dist=(free[:,0]-py)**2+(free[:,1]-px)**2;k=int(np.argmin(dist));row,col=free[k]
        shift=math.sqrt(float(dist[k]))*res
        if shift>1.0:raise ValueError(f'Port {name} requires unsupported snap {shift:.2f}m')
        lookup[name]=int(ids[row,col]);snaps.append(dict(node=name,requested_u=q[0],requested_v=q[1],grid_u=x0+col*res,grid_v=y1-row*res,snap_m=shift))
    names=list(lookup);dist,pred=dijkstra(graph,indices=[lookup[n] for n in names],return_predecessors=True,directed=False)
    pair={};paths={};inverse=free
    for i,a in enumerate(names):
      for b in names[i+1:]:
        val=float(dist[i,lookup[b]])
        if not math.isfinite(val):continue
        pair[(a,b)]=val
        cur=lookup[b];seq=[]
        while cur!=lookup[a]:
            row,col=inverse[cur];seq.append([x0+int(col)*res,y1-int(row)*res]);cur=int(pred[i,cur])
            if cur<0:raise RuntimeError('broken path')
        row,col=inverse[cur];seq.append([x0+int(col)*res,y1-int(row)*res]);paths[(a,b)]=seq[::-1]
    return dict(pairs=pair,paths=paths,snaps=snaps,mask=mask,bounds=bounds)

def route(floors,profile,outage):
    adj={n:[] for n in PORTS}
    for floor,r in floors.items():
      for (a,b),d in r['pairs'].items():
        adj[a].append((b,d,0,0,'WALK'));adj[b].append((a,d,0,0,'WALK'))
    for a,b,kind,serial in VERTICAL:
        if serial in outage or (kind=='STAIR' and profile=='NO_STAIRS'):continue
        ne=1 if kind=='EL' else 0;nh=4.4 if kind=='STAIR' else 0
        # Count the staircase's horizontal progress as self-propelled movement.
        # Excluding it would mechanically exaggerate the elevator detour.
        run=float(np.linalg.norm(np.array(PORTS[a][1])-np.array(PORTS[b][1]))) if kind=='STAIR' else 0.
        adj[a].append((b,run,nh,ne,serial));adj[b].append((a,run,nh,ne,serial))
    cost={'J2':(0.,0.,0)};prev={};q=[(0.,0.,0,'J2')]
    while q:
      d,h,e,a=heapq.heappop(q)
      if cost.get(a)!=(d,h,e):continue
      for b,w,dh,de,edge in adj[a]:
        nd=(d+w,h+dh,e+de)
        if nd<cost.get(b,(math.inf,math.inf,math.inf)):
            cost[b]=nd;prev[b]=(a,edge);heapq.heappush(q,(*nd,b))
    rows=[];details={}
    for target in [f'{p}{i}' for p in ['M','H'] for i in range(1,5)]:
        reachable=target in cost;path=[];facilities=[]
        if reachable:
            cur=target
            while cur!='J2':
                a,edge=prev[cur];path.append([a,cur,edge]);cur=a
            path=path[::-1];facilities=[e for a,b,e in path if e!='WALK']
        stair_plan=sum(float(np.linalg.norm(np.array(PORTS[a][1])-np.array(PORTS[b][1]))) for a,b,e in path if e in ['SNW','SNE','SSW','SSE'])
        rows.append(dict(origin='J2',target=target,platform='마장 방면' if target[0]=='M' else '행당 방면',profile=profile,
            outage='+'.join(outage) or 'NONE',reachable=reachable,walk_m=round(cost[target][0],3) if reachable else '',
            corridor_walk_m=round(cost[target][0]-stair_plan,3) if reachable else '',stair_plan_m=round(stair_plan,3) if reachable else '',
            stair_height_m=cost[target][1] if reachable else '',el_boardings=cost[target][2] if reachable else '',facilities=';'.join(facilities)))
        details[target]=path
    # Independent Floyd-Warshall check of the scalar shortest-distance calculation.
    names=list(PORTS);idx={n:i for i,n in enumerate(names)};n=len(names);fw=np.full((n,n),np.inf);np.fill_diagonal(fw,0)
    for a,edges in adj.items():
      for b,d,*_ in edges:fw[idx[a],idx[b]]=min(fw[idx[a],idx[b]],d)
    for k in range(n):fw=np.minimum(fw,fw[:,k,None]+fw[None,k,:])
    for r in rows:
        v=fw[idx['J2'],idx[r['target']]]
        assert math.isfinite(v)==r['reachable']
        if r['reachable']:assert abs(v-float(r['walk_m']))<.001
    return rows,details

def main():
    annotations=[]
    for name,(floor,q,label) in PORTS.items():
        raw=R.T@np.array(q)
        annotations.append(dict(node=name,floor=floor,u=q[0],v=q[1],raw_x=float(raw[0]),raw_y=float(raw[1]),label=label,
            provenance='model floor/tactile manual review; current inventory and station map for facility identity'))
    csvwrite('reviewed_nodes.csv',annotations)
    jsonwrite('section_definition.json',dict(scope='B4 concourse junction to eight fixed B5 platform points only',
        angle_degrees=-27.68,unit='metre provisionally accepted from independent horizontal checks; no fitted rescaling',
        metric='horizontal self-propelled distance = corridor grid length + staircase approach-to-approach XY length; cabin interior and vertical rise excluded; stair rise reported separately',
        platform_targets='one metre inwards from eight wheelchair floor symbols in historical model; not current door survey',
        vertical_links=VERTICAL,el_height_source='OA-12514 2026-02-11, 4.4m for each B4-B5 EL',
        exclusions=['B1-B2-B4 complete transfer','Korail lines','temporary barriers','queues','wheelchair clearance certification','real failure probabilities'],
        source_glb_sha256=hashlib.sha256((ROOT/'research/sources/wangsimni_smap.glb').read_bytes()).hexdigest()))
    allresults={};lastfloors=None
    for res in [.5,.25]:
        floors={f:build_floor(f,res) for f in ['B4','B5']};rows=[];details={}
        for profile in ['ALL_MODES','NO_STAIRS']:
          for outage in [[],['0103-813'],['0103-814'],['0103-813','0103-814']]:
            rr,dd=route(floors,profile,outage);rows.extend(rr);details[profile+'|'+('+'.join(outage) or 'NONE')]=dd
        csvwrite(f'route_results_grid_{res}.csv',rows)
        allresults[str(res)]=rows;lastfloors=floors
        if res==.25:
            jsonwrite('route_node_sequences.json',details)
            csvwrite('node_grid_snap.csv',[x for f in floors.values() for x in f['snaps']])
            jsonwrite('floor_route_paths.json',{f:{a+'|'+b:seq for (a,b),seq in r['paths'].items()} for f,r in floors.items()})
            for f,r in floors.items():Image.fromarray((r['mask']*255).astype(np.uint8)).save(HERE/(f+'_walk_mask.png'))
        print('grid',res,'completed')
    byres={k:{(r['profile'],r['outage'],r['target']):r for r in rows} for k,rows in allresults.items()}
    comparison=[]
    for target in [f'{p}{i}' for p in ['M','H'] for i in range(1,5)]:
        d=byres['0.25'];a=d['ALL_MODES','NONE',target];b=d['NO_STAIRS','NONE',target]
        comparison.append(dict(target=target,platform=a['platform'],all_modes_walk_m=a['walk_m'],no_stairs_walk_m=b['walk_m'],extra_walk_m=round(b['walk_m']-a['walk_m'],3),all_modes_corridor_m=a['corridor_walk_m'],all_modes_stair_plan_m=a['stair_plan_m'],all_modes_stair_height_m=a['stair_height_m']))
    csvwrite('additional_distance.csv',comparison)
    diffs=[abs(float(v['walk_m'])-float(byres['0.5'][k]['walk_m'])) for k,v in byres['0.25'].items() if v['reachable'] and byres['0.5'][k]['reachable']]
    jsonwrite('calculation_checks.json',dict(independent_floyd_warshall='passed all scenarios',resolution_max_distance_change_m=max(diffs),
        max_node_snap_m=max(x['snap_m'] for f in lastfloors.values() for x in f['snaps']),
        reachability_agrees_between_resolutions=all(v['reachable']==byres['0.5'][k]['reachable'] for k,v in byres['0.25'].items()),
        note='These checks validate the calculation under the annotated graph, not completeness of current station geography.'))
    print(json.dumps(comparison,ensure_ascii=False))

if __name__=='__main__':main()
