"""Check finer grid resolution and save the final route paths."""
import analyze_verified_section as a
import json,csv,math
from PIL import Image
import numpy as np

floors={f:a.build_floor(f,.125) for f in ['B4','B5']}
rows=[]
sequences={}
for profile in ['ALL_MODES','NO_STAIRS']:
  for outage in [[],['0103-813'],['0103-814'],['0103-813','0103-814']]:
    r,s=a.route(floors,profile,outage);rows.extend(r);sequences[profile+'|'+('+'.join(outage) or 'NONE')]=s
a.csvwrite('route_results_grid_0.125.csv',rows)
a.jsonwrite('route_node_sequences_fine.json',sequences)
a.jsonwrite('floor_route_paths_fine.json',{f:{x+'|'+y:seq for (x,y),seq in r['paths'].items()} for f,r in floors.items()})
for f,r in floors.items():Image.fromarray((r['mask']*255).astype(np.uint8)).save(a.HERE/(f+'_walk_mask_fine.png'))
base=list(csv.DictReader((a.HERE/'route_results_grid_0.25.csv').open(encoding='utf-8-sig')))
lookup={(r['profile'],r['outage'],r['target']):r for r in rows}
diff=[];comparison=[]
for r in base:
    s=lookup[r['profile'],r['outage'],r['target']]
    assert (r['reachable']=='True')==s['reachable']
    if s['reachable']:diff.append(abs(float(r['walk_m'])-s['walk_m']))
for t in [f'{p}{i}' for p in ['M','H'] for i in range(1,5)]:
    x=lookup['ALL_MODES','NONE',t];y=lookup['NO_STAIRS','NONE',t]
    old=next(r for r in base if r['profile']=='ALL_MODES' and r['outage']=='NONE' and r['target']==t)
    oldn=next(r for r in base if r['profile']=='NO_STAIRS' and r['outage']=='NONE' and r['target']==t)
    comparison.append(dict(target=t,all_modes_m=x['walk_m'],no_stairs_m=y['walk_m'],extra_m=round(y['walk_m']-x['walk_m'],3),
        previous_extra_m=round(float(oldn['walk_m'])-float(old['walk_m']),3)))
a.csvwrite('fine_grid_comparison.csv',comparison)
a.jsonwrite('fine_grid_checks.json',dict(reachability_unchanged=True,max_distance_change_m=max(diff),note='Grid sensitivity only; not survey uncertainty or endpoint-location uncertainty'))
print(json.dumps({'max_change':max(diff),'comparison':comparison},ensure_ascii=False))
