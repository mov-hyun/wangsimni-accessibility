"""Evidence-bounded distance ranges, replacement bounds, and information regret.

Run: python research/range_model/conditional_range_model.py
No current whole-station distance is estimated. Unknown upper legs remain symbols.
All outputs are written beside this script; source research artifacts are read-only.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import csv, json, math, heapq, itertools, hashlib, importlib.util
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

HERE = Path(__file__).resolve().parent
EXT = HERE.parent / 'metric_extension'
GEO = HERE.parent / 'geometry'
spec = importlib.util.spec_from_file_location('metric_extension_read_only', EXT/'extend_checked_section.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
ORIGINS = [f'TREAD{i}_BOTTOM_PLUS1' for i in range(4)]
TARGETS = [f'{p}{i}' for p in ['M','H'] for i in range(1,5)]
FAILURES = {'EL2':['0103-813'], 'EL3':['0103-814'], 'EL2_EL3':['0103-813','0103-814']}
PROFILES = ['STAIRS_ALLOWED', 'EL_REQUIRED', 'ES_ALLOWED_NO_STAIRS']

def readcsv(p):
    with p.open(encoding='utf-8-sig', newline='') as f:return list(csv.DictReader(f))
def csvsave(name, rows):
    with (HERE/name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def jsave(name, value):
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def rounded(x):return round(float(x),6) if math.isfinite(x) else ''
def floor_dist(floors,a,b):
    if a==b:return 0.
    fl=m.PORTS[a][0]
    assert fl==m.PORTS[b][0]
    return floors[fl]['pairs'].get((a,b),floors[fl]['pairs'].get((b,a),math.inf))

def load_origins_and_candidates():
    """Finite points of the model's lowest tread footprint, translated +1 m.

    This is an annotation sensitivity set, not a confidence region, actual-door
    region, certified continuous envelope, or current ES serial assignment.
    """
    source=readcsv(EXT/'tread_component_endpoints.csv')
    p=m.Z['B4__1_points'];f=m.Z['B4__1_faces']
    welded,inv=np.unique(np.round(p,2),axis=0,return_inverse=True);wf=inv[f]
    pair=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]])
    n,lab=connected_components(coo_matrix((np.ones(len(pair)),(pair[:,0],pair[:,1])),shape=(len(welded),)*2),directed=False)
    assert n==4
    rows=[];groups={}
    for r in source:
        node=r['node'];c=int(r['component']);groups[node]=[node]
        q=m.R@np.array([float(r['approach_raw_x']),float(r['approach_raw_y'])])
        m.PORTS[node]=('B4',q.tolist(),'fixed model tread-bottom-centre plus one model unit')
        pts=np.unique(p[lab[inv]==c],axis=0).astype(float)
        lower=pts[np.isclose(pts[:,2],pts[:,2].max())]
        upper=pts[np.isclose(pts[:,2],pts[:,2].min())]
        direction=lower[:,:2].mean(0)-upper[:,:2].mean(0);direction/=np.linalg.norm(direction)
        candidates=[(node,q,'centre')]
        for i,point in enumerate(lower):
            name=f'{node}_LOWEST_VERTEX{i}'
            uv=m.R@(point[:2]+direction)
            m.PORTS[name]=('B4',uv.tolist(),'lowest tread footprint vertex translated one model unit outward')
            groups[node].append(name);candidates.append((name,uv,'translated_source_vertex'))
        for name,uv,kind in candidates:
            rows.append(dict(family=node,node=name,component=c,u=uv[0],v=uv[1],candidate_kind=kind,
                source='B4__1 lowest elevation footprint (maximum model Z); Z is negative upward',
                current_equipment_mapping_confirmed=False,continuous_region_bound=False,
                actual_door_uncertainty_bound=False))
    csvsave('landing_annotation_candidates.csv',rows)
    return groups

def graph(floors,profile='STAIRS_ALLOWED',outage=()):
    adj={n:[] for n in m.PORTS}
    for floor,r in floors.items():
        for (a,b),val in r['pairs'].items():
            adj[a].append((b,val,0.,0.,0.,0,'WALK'))
            adj[b].append((a,val,0.,0.,0.,0,'WALK'))
    for a,b,kind,serial in m.base.VERTICAL:
        if serial in outage or (kind=='STAIR' and profile!='STAIRS_ALLOWED'):continue
        run=np.linalg.norm(np.array(m.PORTS[a][1])-m.PORTS[b][1]) if kind=='STAIR' else 0.
        stair=4.4 if kind=='STAIR' else 0.
        elrise=4.4 if kind=='EL' else 0.
        board=int(kind=='EL')
        # An EL has zero horizontal self-propelled component, not zero physical
        # movement. Its separate model vertical travel is explicitly 4.4 m.
        adj[a].append((b,float(run),0.,stair,elrise,board,serial))
        adj[b].append((a,float(run),stair,0.,elrise,board,serial))
    return adj

def shortest(adj,start):
    # First minimize horizontal self-propelled distance; ties: stairs, EL count.
    cost={start:(0.,0.,0)};vec={start:(0.,0.,0.,0.,0)};prev={};q=[(0.,0.,0,start)]
    while q:
        d,s,e,a=heapq.heappop(q)
        if cost.get(a)!=(d,s,e):continue
        for b,w,up,down,elv,eb,edge in adj[a]:
            c=(d+w,s+up+down,e+eb)
            if c<cost.get(b,(math.inf,)*3):
                cost[b]=c;v=vec[a]
                vec[b]=(v[0]+w,v[1]+up,v[2]+down,v[3]+elv,v[4]+eb)
                prev[b]=(a,edge);heapq.heappush(q,(*c,b))
    return cost,vec,prev

def path(prev,start,end):
    p=[]
    while end!=start:
        a,edge=prev[end];p.append((a,end,edge));end=a
    return p[::-1]

def floyd(adj):
    names=list(adj);ix={n:i for i,n in enumerate(names)}
    d=np.full((len(names),len(names)),math.inf);np.fill_diagonal(d,0)
    for a,edges in adj.items():
        for b,w,*rest in edges:d[ix[a],ix[b]]=min(w,d[ix[a],ix[b]])
    for k in range(len(names)):d=np.minimum(d,d[:,k,None]+d[None,k,:])
    return names,ix,d

def paired_affine_range(normal,outage,lower=None,upper=None):
    """Exact infimum/supremum of min(U_i+b_i)-min(U_i+a_i) by active pairs.

    U_i is the SAME unknown upper horizontal cost in normal and outage worlds.
    Missing observations are never installed as zero-length graph edges.
    Default lower=0 expresses only a nonnegative infimum; it is not an assigned
    measured length. Strictly positive unmeasured links have the same infimum.
    None upper is unbounded. A missing outage alternative is math.inf; if all
    are absent, return disconnected separately, never a large distance penalty.
    """
    a=np.asarray(normal,float);b=np.asarray(outage,float);n=len(a)
    if not np.isfinite(a).any():return dict(status='normal_disconnected',lower=None,upper=None,lp_checks=0)
    if not np.isfinite(b).any():return dict(status='outage_disconnected',lower=None,upper=None,lp_checks=0)
    bounds=list(zip([0.]*n if lower is None else lower,[None]*n if upper is None else upper))
    lo=math.inf;hi=-math.inf;calls=0
    for i in np.flatnonzero(np.isfinite(a)):
      for j in np.flatnonzero(np.isfinite(b)):
        A=[];B=[]
        for k in np.flatnonzero(np.isfinite(a)):
            row=np.zeros(n);row[i]+=1;row[k]-=1;A.append(row);B.append(a[k]-a[i])
        for k in np.flatnonzero(np.isfinite(b)):
            row=np.zeros(n);row[j]+=1;row[k]-=1;A.append(row);B.append(b[k]-b[j])
        c=np.zeros(n);c[j]+=1;c[i]-=1;constant=b[j]-a[i]
        for sign in [1,-1]:
            opt=linprog(sign*c,A_ub=A,b_ub=B,bounds=bounds,method='highs');calls+=1
            if opt.status==2:continue
            if opt.status==3:
                if sign==1:lo=-math.inf
                else:hi=math.inf
            else:
                assert opt.success,opt.message
                value=float(c@opt.x+constant)
                if sign==1:lo=min(lo,value)
                else:hi=max(hi,value)
    assert lo<=hi
    return dict(status='finite' if math.isfinite(lo) and math.isfinite(hi) else 'unbounded',
        lower=lo if math.isfinite(lo) else None,upper=hi if math.isfinite(hi) else None,lp_checks=calls)

def local_calculations(res,groups):
    floors={'B4':m.build_b4(res,save_mask=False),'B5':m.cached_b5(res)}
    csvsave(f'candidate_snap_{res}.csv',floors['B4']['snaps'])
    cache={};rows=[];independent=0
    origins=[n for group in groups.values() for n in group]
    for profile in PROFILES:
      for label,outage in {'NONE':[],**FAILURES}.items():
        adj=graph(floors,profile,outage);names,idx,fw=floyd(adj)
        for o in origins+['E2_4','E3_4']+TARGETS:
            cost,vec,prev=shortest(adj,o);cache[(profile,label,o)]=(cost,vec,prev)
            # Both directions and every annotated origin checked independently.
            for t in TARGETS if m.PORTS[o][0]=='B4' else origins:
                ok=t in cost
                assert ok==math.isfinite(fw[idx[o],idx[t]])
                if ok:assert abs(cost[t][0]-fw[idx[o],idx[t]])<1e-7
                independent+=1
                if o not in origins:continue
                v=vec.get(t,(math.inf,)*5)
                rows.append(dict(grid_m=res,origin=o,target=t,profile=profile,outage=label,reachable=ok,
                    horizontal_self_propelled_model_m=rounded(v[0]),stair_ascent_m=rounded(v[1]),
                    stair_descent_m=rounded(v[2]),el_vertical_model_m=rounded(v[3]),
                    el_boardings=int(v[4]) if ok else '',es_ride_model_m=0,
                    physical_total_m='',scope='B4 to B5 local model; horizontal and vertical components separated'))
    csvsave(f'local_paired_worlds_{res}.csv',rows)
    return floors,cache,rows,independent

def main():
    originals=[EXT/'local_extension_results_0.125.csv',EXT/'local_extension_results_0.25.csv',
        GEO/'mesh_arrays.npz',EXT/'extend_checked_section.py']
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
    groups=load_origins_and_candidates();worlds={};independent=0
    for res in [.25,.125]:
        floors,cache,rows,n=local_calculations(res,groups);worlds[res]=(floors,cache,rows);independent+=n
        print(f'grid {res}: {len(rows)} local rows; {n} independent comparisons',flush=True)
    floors,cache,rows=worlds[.125]
    # Preserve the previously published fixed-node calculation exactly.
    replicated=0
    old=readcsv(EXT/'local_extension_results_0.125.csv')
    for r in old:
        if r['origin'] not in ORIGINS:continue
        outage=next((k for k,v in FAILURES.items() if '+'.join(v)==r['outage']),'NONE')
        c=cache[(r['profile'],outage,r['origin'])][0]
        assert (r['target'] in c)==(r['reachable']=='True')
        if r['reachable']=='True':assert abs(c[r['target']][0]-float(r['horizontal_self_propelled_model_m']))<.00051
        replicated+=1

    # Correlated coordinate sensitivity: pair identical candidate ports before
    # taking min/max. Never subtract independently optimized interval endpoints.
    sens=[]
    for family,candidates in groups.items():
      for profile in PROFILES:
       for target in TARGETS:
        for label in FAILURES:
            pairs=[]
            for o in candidates:
                c0=cache[(profile,'NONE',o)][0];c1=cache[(profile,label,o)][0]
                if target in c0 and target in c1:pairs.append((c0[target][0],c1[target][0]))
            sens.append(dict(family=family,target=target,profile=profile,outage=label,
                candidate_count=len(candidates),reachable_candidate_count=len(pairs),
                normal_min=rounded(min(a for a,b in pairs)) if pairs else '',
                normal_max=rounded(max(a for a,b in pairs)) if pairs else '',
                outage_min=rounded(min(b for a,b in pairs)) if pairs else '',
                outage_max=rounded(max(b for a,b in pairs)) if pairs else '',
                paired_delta_min=rounded(min(b-a for a,b in pairs)) if pairs else '',
                paired_delta_max=rounded(max(b-a for a,b in pairs)) if pairs else '',
                interpretation='finite model annotation candidates; not continuous bound, CI, survey error, or actual distance'))
    csvsave('paired_annotation_sensitivity.csv',sens)

    # Unknown shared upper approaches: enumerate connection subsets, not their
    # averages. Every subset is a separate topology assumption and fixed OD.
    envelopes=[];lp_checks=0
    for profile in PROFILES:
     for target in TARGETS:
      for label in FAILURES:
       for bits in itertools.product([0,1],repeat=4):
        ids=[i for i,v in enumerate(bits) if v]
        if not ids:continue
        aa=[cache[(profile,'NONE',ORIGINS[i])][0].get(target,(math.inf,))[0] for i in ids]
        bb=[cache[(profile,label,ORIGINS[i])][0].get(target,(math.inf,))[0] for i in ids]
        # Analytic min-of-shared-affine envelope is exact for unbounded U_i.
        finite=all(math.isfinite(v) for v in bb)
        low=min(b-a for a,b in zip(aa,bb)) if finite else None
        high=max(b-a for a,b in zip(aa,bb)) if finite else None
        # Independent LP checks all-subset representative target M2, both stairs
        # and no-stairs profiles, and all targets when all four ingresses exist.
        if target=='M2' or len(ids)==4:
            result=paired_affine_range(aa,bb);lp_checks+=result['lp_checks']
            assert (result['status']=='finite')==finite
            if finite:assert abs(result['lower']-low)<1e-7 and abs(result['upper']-high)<1e-7
        envelopes.append(dict(profile=profile,target=target,outage=label,
            available_fixed_ingress_subset=';'.join(ORIGINS[i] for i in ids),
            status='finite_conditional_delta' if finite else 'outage_disconnected_in_restricted_local_graph',
            upper_approach_symbols=';'.join(f'U{i}' for i in ids),
            normal_formula='min('+','.join(f'U{i}+{a:.6f}' for i,a in zip(ids,aa))+')',
            outage_formula='min('+','.join(f'U{i}+{b:.6f}' for i,b in zip(ids,bb))+')' if finite else 'no local path',
            delta_infimum=rounded(low) if finite else '',delta_supremum=rounded(high) if finite else '',
            whole_horizontal_distance_upper_bound='',
            qualification='same OD, same U_i in both worlds; unchanged upper links; these ingresses only; no actual station claim'))
    csvsave('conditional_shared_prefix_envelopes.csv',envelopes)

    # A replacement path at the failed EL entry gives a bound independent of
    # where the route first entered B4. Includes an unidentified EL1 B4 arrival.
    replacement=[];regret=[];bound_checks=0;reverse_checks=0;grid_check=[]
    for label,entry in [('EL2','E2_4'),('EL3','E3_4')]:
      for target in TARGETS:
        c0=cache[('STAIRS_ALLOWED','NONE',entry)][0]
        c1=cache[('STAIRS_ALLOWED',label,entry)][0]
        B=c1[target][0]-c0[target][0]
        assert B>=-1e-7
        for o in [n for vs in groups.values() for n in vs]:
            d0=cache[('STAIRS_ALLOWED','NONE',o)][0][target][0]
            d1=cache[('STAIRS_ALLOWED',label,o)][0][target][0]
            assert -1e-7<=d1-d0<=B+1e-7;bound_checks+=1
        reverse_failed_exit='E2_5' if label=='EL2' else 'E3_5'
        rev0=shortest(graph(floors,'STAIRS_ALLOWED',[]),reverse_failed_exit)[0]
        rev1=shortest(graph(floors,'STAIRS_ALLOWED',FAILURES[label]),reverse_failed_exit)[0]
        edge_replacement=c1[reverse_failed_exit][0]
        assert abs(edge_replacement-rev1[entry][0])<1e-7
        # The tighter target-specific bound assumes the full route ends with
        # this exact local B4-to-target subgraph. The edge bound instead rejoins
        # the precise opposite EL entry and is valid even if other unknown
        # parts of a larger graph subsequently compete with the known suffix.
        replacement.append(dict(outage=label,target=target,failed_entry=entry,
            local_normal_from_entry=c0[target][0],local_outage_from_entry=c1[target][0],
            local_suffix_full_optimum_delta_lower_bound=0.,local_suffix_full_optimum_delta_upper_bound=B,
            universal_same_graph_EL_edge_replacement_upper_bound=edge_replacement,
            reverse_full_walk_bound_same=True,stairs_forward='descent',stairs_reverse='ascent',
            bound_scope='Tight target bound requires final suffix confined to checked B4-B5 graph; universal edge bound rejoins opposite EL approach; upper links unchanged; stairs permitted',
            current_operational_or_whole_actual_claim=False))
        for o in ORIGINS:
            normal,_,prev=cache[('STAIRS_ALLOWED','NONE',o)]
            p=path(prev,o,target);serial=FAILURES[label][0]
            uses=any(e==serial for a,b,e in p)
            early=cache[('STAIRS_ALLOWED',label,o)][0][target][0]
            prefix=floor_dist(floors,o,entry) if uses else 0.
            late=prefix+c1[target][0] if uses else normal[target][0]
            # If the chosen normal route does not use the stopped facility,
            # monotonicity implies that it remains optimal and needs no reroute.
            assert late>=early-1e-7
            regret.append(dict(origin=o,target=target,direction='FORWARD_B4_TO_B5',outage=label,normal_route_used_failed_EL=uses,
                normal=normal[target][0],early_information_distance=early,
                late_information_distance=late,late_information_extra=late-early,
                common_upper_prefix='U_'+o,upper_prefix_cancels=True,
                interpretation='Discovery exactly at reviewed B4 approach; immediate optimal reroute; queue and inspection time excluded',
                current_wayfinding_saving_measured=False))
            reverse_normal,reverse_vec,reverse_prev=cache[('STAIRS_ALLOWED','NONE',target)]
            reverse_out=cache[('STAIRS_ALLOWED',label,target)][0]
            assert abs(reverse_normal[o][0]-normal[target][0])<1e-7
            assert abs(reverse_out[o][0]-early)<1e-7
            reverse_checks+=2
            rp=path(reverse_prev,target,o);ruses=any(e==serial for a,b,e in rp)
            rprefix=floor_dist(floors,target,reverse_failed_exit) if ruses else 0.
            rlate=rprefix+rev1[o][0] if ruses else reverse_normal[o][0]
            assert rlate>=reverse_out[o][0]-1e-7
            regret.append(dict(origin=target,target=o,direction='REVERSE_B5_TO_B4',outage=label,
                normal_route_used_failed_EL=ruses,normal=reverse_normal[o][0],
                early_information_distance=reverse_out[o][0],late_information_distance=rlate,
                late_information_extra=rlate-reverse_out[o][0],common_upper_prefix='U_'+o,
                upper_prefix_cancels=True,
                interpretation='Discovery exactly at reviewed B5 approach; common upper suffix cancels; immediate optimal reroute; queues excluded',
                current_wayfinding_saving_measured=False))
    for res,(fl,ca,_) in worlds.items():
        o=ORIGINS[0];target='M2';entry='E3_4';exit='E3_5'
        norm=ca[('STAIRS_ALLOWED','NONE',o)][0][target][0]
        early=ca[('STAIRS_ALLOWED','EL3',o)][0][target][0]
        late=floor_dist(fl,o,entry)+ca[('STAIRS_ALLOWED','EL3',entry)][0][target][0]
        edge=ca[('STAIRS_ALLOWED','EL3',entry)][0][exit][0]
        bound=ca[('STAIRS_ALLOWED','EL3',entry)][0][target][0]-ca[('STAIRS_ALLOWED','NONE',entry)][0][target][0]
        oi=ORIGINS[2];ti='M1'
        early_i=ca[('STAIRS_ALLOWED','EL3',oi)][0][ti][0]
        late_i=floor_dist(fl,oi,entry)+ca[('STAIRS_ALLOWED','EL3',entry)][0][ti][0]
        reverse_at_exit=shortest(graph(fl,'STAIRS_ALLOWED',FAILURES['EL3']),exit)[0]
        reverse_late_i=floor_dist(fl,ti,exit)+reverse_at_exit[oi][0]
        grid_check.append(dict(grid_m=res,origin=o,target=target,normal=norm,outage=early,paired_delta=early-norm,
            early_information_advantage=late-early,local_suffix_bound=bound,universal_edge_bound=edge,
            TREAD2_M1_forward_information_extra=late_i-early_i,
            M1_TREAD2_reverse_information_extra=reverse_late_i-early_i,
            interpretation='two deterministic grid resolutions; comparison is not a confidence interval'))
    csvsave('local_replacement_full_delta_bounds.csv',replacement)
    csvsave('early_vs_at_facility_information.csv',regret)
    csvsave('representative_grid_diagnostics.csv',grid_check)

    # Pareto set under one B4-to-B5 crossing. Independently verify its minimum
    # horizontal distance equals unrestricted local Dijkstra for every case.
    pareto=[];effort=[];pareto_checks=0
    for o in ORIGINS:
      for target in TARGETS:
        candidates=[]
        for a,b,kind,serial in m.base.VERTICAL:
            first=floor_dist(floors,o,a);last=floor_dist(floors,b,target)
            if not math.isfinite(first+last):continue
            run=float(np.linalg.norm(np.array(m.PORTS[a][1])-m.PORTS[b][1])) if kind=='STAIR' else 0.
            candidates.append(dict(facility=serial,kind=kind,walk=first+run+last,stair=4.4 if kind=='STAIR' else 0.,
                el_vertical=4.4 if kind=='EL' else 0.,stair_plan=run))
        assert abs(min(x['walk'] for x in candidates)-cache[('STAIRS_ALLOWED','NONE',o)][0][target][0])<1e-7
        pareto_checks+=1
        front=[x for x in candidates if not any(y['walk']<=x['walk']+1e-9 and y['stair']<=x['stair'] and
            (y['walk']<x['walk']-1e-9 or y['stair']<x['stair']) for y in candidates)]
        for direction in ['FORWARD_B4_TO_B5','REVERSE_B5_TO_B4']:
            for x in front:
                pareto.append(dict(origin=o if direction.startswith('FORWARD') else target,
                    target=target if direction.startswith('FORWARD') else o,direction=direction,
                    facility=x['facility'],horizontal_self_propelled_model_m=x['walk'],
                    stair_ascent_m=x['stair'] if direction.startswith('REVERSE') else 0,
                    stair_descent_m=x['stair'] if direction.startswith('FORWARD') else 0,
                    el_vertical_model_m=x['el_vertical'],one_vertical_crossing=True,
                    objective='minimize horizontal self-propelled distance and stair vertical movement; EL wait unweighted'))
        s=min((x for x in candidates if x['kind']=='STAIR'),key=lambda x:x['walk'])
        e=min((x for x in candidates if x['kind']=='EL'),key=lambda x:x['walk'])
        saving=e['walk']-s['walk'];threshold=saving/4.4
        effort.append(dict(origin=o,target=target,stairs_walk=s['walk'],el_walk=e['walk'],
            walk_saved_by_stairs=saving,stair_vertical_m=4.4,
            lambda_break_even_walk_equivalent_per_vertical_m=max(0.,threshold),
            stairs_can_be_optimal_for_nonnegative_lambda=saving>0,
            formula='cost=horizontal_walk+lambda_down*4.4 forward; lambda_up*4.4 reverse; no fitted preference',
            ascent_descent_weights_estimated=False))
    csvsave('distance_stair_burden_pareto.csv',pareto)
    csvsave('stair_effort_break_even.csv',effort)

    thresholds=[]
    for profile in PROFILES:
      for target in TARGETS:
       for i,j in itertools.combinations(range(4),2):
        a=cache[(profile,'NONE',ORIGINS[i])][0][target][0]
        b=cache[(profile,'NONE',ORIGINS[j])][0][target][0]
        thresholds.append(dict(profile=profile,target=target,ingress_A=ORIGINS[i],ingress_B=ORIGINS[j],
            local_A=a,local_B=b,B_can_add_upper_horizontal_relative_to_A=a-b,
            condition=f'U{j}-U{i} <= {a-b:.6f}',
            qualification='same exact L2 origin; both upper routes feasible for profile and direction; ES riding separate'))
    csvsave('upper_route_break_even.csv',thresholds)

    # A removed upper route has no finite metric bound from connectivity alone.
    # Two distinct alternatives: a measured local constant plus unknown U_i.
    a=[cache[('STAIRS_ALLOWED','NONE',o)][0]['M2'][0] for o in ORIGINS]
    b=[cache[('STAIRS_ALLOWED','EL3',o)][0]['M2'][0] for o in ORIGINS]
    exact=paired_affine_range(a,b);lp_checks+=exact['lp_checks']
    removed=paired_affine_range(a,[math.inf,math.inf,b[2],b[3]]);lp_checks+=removed['lp_checks']
    assert removed['status']=='unbounded' and removed['upper'] is None
    certificate=[]
    # A constructive algebra check uses thresholds, not candidate real distances.
    # Vary a common unknown offset t: every full length increases by t, while
    # paired delta stays fixed. The CSV stores expressions, never these as data.
    certificate.append(dict(case='WHOLE_HORIZONTAL_LENGTH',normal='min_i(U_i+a_i)',outage='min_i(U_i+b_i)',
        upper_bound='unbounded from available evidence',proof='Replace every U_i by U_i+t for arbitrarily large t; normal and outage each increase by t.',
        physical_total='also lacks ES ride lengths and EL door/cabin segments',disconnection='not used as infinity penalty'))
    certificate.append(dict(case='EL3_ONLY_SHARED_INGRESSES',normal='min_i(U_i+a_i)',outage='min_i(U_i+b_i)',
        upper_bound=f'delta <= {exact["upper"]:.6f}',proof='min_i(b_i-a_i) <= difference of minima <= max_i(b_i-a_i); same U in both worlds.',
        physical_total='bound applies to horizontal self-propelled component only',disconnection='all four B4 ingresses remain locally connected when stairs allowed'))
    certificate.append(dict(case='UPPER_LINK_REMOVAL',normal='min_i(U_i+a_i)',outage='min_{surviving i}(U_i+b_i)',
        upper_bound='unbounded from available evidence',proof='Keep a removed alternative finite; increase all surviving U_i by t; outage cost grows without bound.',
        physical_total='do not infer recovery distance from mechanical boarding counts',disconnection='if no surviving path, disconnected is a separate state'))
    csvsave('bound_identifiability_certificates.csv',certificate)

    metric_rules=[
        dict(component='horizontal_self_propelled',definition='corridor grid distance plus stair plan projection',unmeasured='upper walking legs; actual door offsets; current obstacles',zero_semantics='EL/ES rides contribute zero only to this component'),
        dict(component='stair_ascent_descent',definition='vertical height up/down separately; local B4-B5 = 4.4 m',unmeasured='upper intermediate stairs and actual riser count',zero_semantics='mechanical lift is not active stair ascent'),
        dict(component='ES_ride',definition='path travelled while carried on ES, separately from walking',unmeasured='current matched endpoint length, ES bank serial mapping',zero_semantics='unavailable is blank, never zero'),
        dict(component='EL_vertical',definition='vertical model/cabin displacement, separate from self-propelled distance',unmeasured='upper EL boarding ports and door/cabin walking',zero_semantics='B4-B5 uses 4.4, not zero'),
        dict(component='physical_total',definition='needs consistent stair path convention, ES riding path, EL travel and cabin/door segments',unmeasured='cannot add plan distance to 3D ES chord and call it real full distance',zero_semantics='not computed'),
        dict(component='topology',definition='each feasible connection set and travel direction is a separate world',unmeasured='Korail step-free link, stop access, lift operation and ES bank directions',zero_semantics='missing connection is unknown or absent, never a free shortcut')]
    csvsave('metric_definitions.csv',metric_rules)
    banks=[
        dict(bank='central_5호선_ES1_ES2',direction='central hall to B4',serials='1800-560;1800-561',single_unit='parallel mate remains in conditional topology; lateral access distance unknown',all_units='removes bank; alternate upper-route metric unbounded',common_cause='power/landing/corridor closure may also remove nearby alternatives; do not multiply independent probabilities'),
        dict(bank='central_5호선_ES3_ES4',direction='B4 to central hall',serials='1800-562;1800-563',single_unit='same conditional qualification',all_units='reverse direction affected separately',common_cause='same'),
        dict(bank='north_5호선_ES5_ES6',direction='B4 to L2 SANG under registry topology',serials='1800-564;1800-565',single_unit='parallel mate remains; no exact zero detour claim',all_units='reverse L5-to-L2 routing affected',common_cause='same'),
        dict(bank='south_5호선_ES7_ES8',direction='ES7 down, ES8 up under current topology',serials='1800-566;1800-567',single_unit='opposite-direction mate is not automatically usable',all_units='both directions removed',common_cause='no automatic stopped-ES-as-stairs assumption'),
        dict(bank='Korail_short_ES',direction='current ES8 UP conflicts with prior DN; unresolved',serials='1800-364;1800-365;1800-366;1800-371',single_unit='direction scenarios retained separately',all_units='all-unit outage avoids direction ambiguity; conditional EL5 backup',common_cause='EL5 may share corridor/power constraints; independence unmeasured')]
    csvsave('es_bank_failure_rules.csv',banks)
    sources=[dict(path=str(p.relative_to(HERE.parent.parent)),sha256=before[str(p)]) for p in originals]
    after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in originals};assert before==after
    representative=dict(
        shared_prefix_fixed_TREAD0_M2=[a[0],b[0],b[0]-a[0]],
        shared_upper_unknown_four_ingress_M2_exact_delta=[exact['lower'],exact['upper']],
        EL3_replacement_M2=next(r for r in replacement if r['outage']=='EL3' and r['target']=='M2'),
        information_TREAD0_M2=next(r for r in regret if r['origin']==ORIGINS[0] and r['target']=='M2' and r['outage']=='EL3'),
        stair_tradeoff_TREAD2_M3=next(r for r in effort if r['origin']==ORIGINS[2] and r['target']=='M3'),
        candidate_sensitivity_TREAD0_M2=next(r for r in sens if r['family']==ORIGINS[0] and r['target']=='M2' and r['outage']=='EL3' and r['profile']=='STAIRS_ALLOWED'))
    checks=dict(source_hashes_unchanged=True,sources=sources,independent_floyd_checks=independent,
        existing_results_reproduced=replicated,linear_program_calls=lp_checks,
        replacement_bound_checks=bound_checks,reverse_distance_symmetry_checks=reverse_checks,
        one_crossing_pareto_minimum_checks=pareto_checks,
        finite_candidate_count=sum(map(len,groups.values())),topology_envelope_rows=len(envelopes),
        unknown_upper_lengths_assigned=False,confidence_interval_claimed=False,
        continuous_candidate_region_bound_claimed=False,current_full_actual_distance_claimed=False,
        ES_riding_field_used_to_scale_walk=False,report_created=False,representative=representative)
    jsave('range_checks.json',checks)
    jsave('representative_values.json',representative)
    print(json.dumps(checks,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
