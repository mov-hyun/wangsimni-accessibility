"""Independent output invariants plus exact finite-box algebra checks.

The small algebra test fixtures are not station data or estimated missing legs.
"""
from pathlib import Path
import sys,csv,json,math,itertools
sys.dont_write_bytecode=True
import numpy as np
from conditional_range_model import paired_affine_range
HERE=Path(__file__).resolve().parent
def rows(name):
    with (HERE/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def main():
    # Independent exhaustive grid check. All breakpoints of these integer-coefficient
    # two-variable affine fixtures lie on the enumerated integer grid.
    tests=[([2,7],[6,9],[1,1],[12,12]),([3,8],[math.inf,10],[1,1],[15,15]),
        ([3,8],[4,20],[5,2],[10,7])]
    toy_checks=0
    for a,b,lower,upper in tests:
        exact=paired_affine_range(a,b,lower,upper)
        vals=[min(u[i]+b[i] for i in range(2))-min(u[i]+a[i] for i in range(2))
            for u in itertools.product(*(range(lower[i],upper[i]+1) for i in range(2)))]
        assert exact['status']=='finite'
        assert abs(exact['lower']-min(vals))<1e-9 and abs(exact['upper']-max(vals))<1e-9
        toy_checks+=1
    assert paired_affine_range([2,7],[math.inf,math.inf])['status']=='outage_disconnected'
    unbounded=paired_affine_range([2,7],[math.inf,9])
    assert unbounded['status']=='unbounded' and unbounded['upper'] is None

    local=rows('local_paired_worlds_0.125.csv')
    ix={(r['origin'],r['target'],r['profile'],r['outage']):r for r in local}
    monotonic=0;profile_equal=0
    for r in local:
        if r['outage']!='NONE' and r['reachable']=='True':
            base=ix[(r['origin'],r['target'],r['profile'],'NONE')]
            assert float(r['horizontal_self_propelled_model_m'])>=float(base['horizontal_self_propelled_model_m'])-1e-6
            monotonic+=1
        if r['profile']=='ES_ALLOWED_NO_STAIRS':
            el=ix[(r['origin'],r['target'],'EL_REQUIRED',r['outage'])]
            for k in ['reachable','horizontal_self_propelled_model_m','stair_ascent_m','stair_descent_m','el_vertical_model_m']:
                assert r[k]==el[k]
            profile_equal+=1
        if r['reachable']=='True':
            assert (float(r['el_vertical_model_m'])==4.4)==(r['el_boardings']=='1')
            assert r['physical_total_m']==''
    source={}
    for r in local:
        if r['origin'].endswith('PLUS1'):
            source[(r['origin'],r['target'],r['profile'],r['outage'])]=r
    rng=np.random.default_rng(1731);real_affine_checks=0
    env=rows('conditional_shared_prefix_envelopes.csv')
    for r in env:
        if r['status']!='finite_conditional_delta':continue
        names=r['available_fixed_ingress_subset'].split(';')
        a=np.array([float(source[(n,r['target'],r['profile'],'NONE')]['horizontal_self_propelled_model_m']) for n in names])
        b=np.array([float(source[(n,r['target'],r['profile'],r['outage'])]['horizontal_self_propelled_model_m']) for n in names])
        lo=float(r['delta_infimum']);hi=float(r['delta_supremum'])
        # U values below are algebra tests, never written as model observations.
        for u in rng.exponential(100,size=(30,len(names))):
            delta=float(np.min(u+b)-np.min(u+a))
            assert lo-2e-6<=delta<=hi+2e-6
            real_affine_checks+=1
    # Coordinate bounds are paired by candidate world, not independent endpoints.
    paired=rows('paired_annotation_sensitivity.csv')
    for r in paired:
        if r['reachable_candidate_count']=='0':continue
        assert float(r['paired_delta_min'])<=float(r['paired_delta_max'])+1e-7
        assert float(r['paired_delta_min'])>=-1e-6
    info=rows('early_vs_at_facility_information.csv')
    for r in info:
        assert abs(float(r['late_information_distance'])-float(r['early_information_distance'])-float(r['late_information_extra']))<1e-7
        assert float(r['late_information_extra'])>=-1e-7
    output=dict(finite_box_exhaustive_checks=toy_checks,disconnected_state_check=True,
        upper_route_removal_unbounded_check=True,local_monotonicity_checks=monotonic,
        EL_ES_no_stairs_equivalence_checks=profile_equal,paired_affine_random_algebra_checks=real_affine_checks,
        information_regret_identity_checks=len(info),random_test_inputs_exported_as_data=False,
        findings='passed',actual_geometry_completeness_verified=False)
    (HERE/'independent_validation.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
