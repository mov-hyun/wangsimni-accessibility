"""Extend B4/B5 metric checks to four model tread-bottom approach points.

These are model geometric landmarks, not eight individually identified current
ES landings and not full Line2-to-Line5 OD. Existing files are read-only.
"""
from pathlib import Path
import csv,json,math,heapq,hashlib,importlib.util
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components,dijkstra
from scipy.ndimage import distance_transform_edt

HERE=Path(__file__).resolve().parent;GEO=HERE.parent/'geometry'
spec=importlib.util.spec_from_file_location('checked_section',GEO/'analyze_verified_section.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
Z=base.Z;R=base.R;PORTS=dict(base.PORTS)

def csvwrite(name,rows):
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def jsave(name,obj):
    (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')

def landings():
    key='B4__1';p=Z[key+'_points'];f=Z[key+'_faces']
    welded,inverse=np.unique(np.round(p,2),axis=0,return_inverse=True);wf=inverse[f]
    pair=np.concatenate([wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]])
    n,lab=connected_components(coo_matrix((np.ones(len(pair)),(pair[:,0],pair[:,1])),shape=(len(welded),)*2),directed=False)
    out=[]
    for c in range(n):
        pts=np.unique(p[lab[inverse]==c],axis=0).astype(float)
        upper=pts[np.isclose(pts[:,2],pts[:,2].min())].mean(axis=0)
        lower=pts[np.isclose(pts[:,2],pts[:,2].max())].mean(axis=0)
        down=(lower[:2]-upper[:2]);run=float(np.linalg.norm(down));down/=run
        approach=lower[:2]+down # exactly one model unit beyond tread-bottom centre
        node=f'TREAD{c}_BOTTOM_PLUS1';uv=R@approach
        PORTS[node]=('B4',uv.tolist(),'one model unit beyond lowest tread centre; current serial mapping unresolved')
        region='LINE2_NORTH_ARM' if c==0 else 'LINE2_SOUTH_ARM' if c==1 else 'CENTRAL_HALL_ARM'
        out.append(dict(node=node,mesh=key,component=c,welded_vertices=int((lab==c).sum()),
            source_vertices=int((lab[inverse]==c).sum()),region=region,
            upper_x=upper[0],upper_y=upper[1],upper_z=upper[2],
            lower_x=lower[0],lower_y=lower[1],lower_z=lower[2],
            tread_center_horizontal_span=run,tread_z_span=float(lower[2]-upper[2]),
            lower_floor_z_gap=float(-5.811890125274658-lower[2]),
            approach_raw_x=approach[0],approach_raw_y=approach[1],
            current_serial='',current_serial_mapping_confirmed=False,
            scope='one connected tread component; not count of all installed escalators'))
    assert n==4
    csvwrite('tread_component_endpoints.csv',out)
    return out

def build_b4(res,save_mask=True):
    # Extended extent; old J2-only B4 mask ended at v=5, excluding the north arm.
    x0,y0,x1,y1=(-20,-65,60,45);w=round((x1-x0)/res)+1;h=round((y1-y0)/res)+1
    img=Image.new('1',(w,h));d=ImageDraw.Draw(img)
    def pixel(p):
        q=R@p[:2];return ((q[0]-x0)/res,(y1-q[1])/res)
    for i in [85,86,87]:
        p=Z[f'B4__{i}_points'];f=Z[f'B4__{i}_faces']
        for t in p[f]:d.polygon([pixel(v) for v in t],fill=1)
    section=-5.81189-.6
    for k in Z.files:
        if not k.startswith('B4__') or not k.endswith('_points'):continue
        p=Z[k];tris=p[Z[k[:-7]+'_faces']]
        for t in tris:
            if not(t[:,2].min()<section<t[:,2].max()):continue
            inter=[]
            for a,b in zip(t,np.roll(t,-1,axis=0)):
                if (a[2]-section)*(b[2]-section)<0:inter.append(a+(b-a)*((section-a[2])/(b[2]-a[2])))
            if len(inter)==2:d.line([pixel(v) for v in inter],fill=0,width=1)
    mask=np.array(img,dtype=bool);mask&=distance_transform_edt(mask)*res>=.2
    ids=np.full(mask.shape,-1,dtype=np.int32);ids[mask]=np.arange(mask.sum(),dtype=np.int32)
    rr=[];cc=[];ww=[]
    for dy in range(-3,4):
      for dx in range(-3,4):
        if not(dx or dy) or math.gcd(abs(dx),abs(dy))!=1 or dx*dx+dy*dy>13:continue
        ys=slice(max(0,-dy),min(h,h-dy));xs=slice(max(0,-dx),min(w,w-dx))
        yd=slice(max(0,dy),min(h,h+dy));xd=slice(max(0,dx),min(w,w+dx))
        ok=mask[ys,xs]&mask[yd,xd]
        for t in np.linspace(0,1,2*max(abs(dx),abs(dy))+1)[1:-1]:
          for oy in {math.floor(dy*t),math.ceil(dy*t)}:
            for ox in {math.floor(dx*t),math.ceil(dx*t)}:
              ok &=mask[ys.start+oy:ys.start+oy+ok.shape[0],xs.start+ox:xs.start+ox+ok.shape[1]]
        if ok.any():
            rr.append(ids[ys,xs][ok]);cc.append(ids[yd,xd][ok]);ww.append(np.full(ok.sum(),res*math.hypot(dx,dy)))
    graph=coo_matrix((np.concatenate(ww),(np.concatenate(rr),np.concatenate(cc))),shape=(int(mask.sum()),)*2).tocsr()
    free=np.column_stack(np.nonzero(mask));lookup={};snaps=[]
    for name,(fl,q,label) in PORTS.items():
        if fl!='B4':continue
        py=(y1-q[1])/res;px=(q[0]-x0)/res;dist=(free[:,0]-py)**2+(free[:,1]-px)**2
        k=int(np.argmin(dist));row,col=free[k];shift=math.sqrt(float(dist[k]))*res
        assert shift<=1,(name,shift)
        lookup[name]=int(ids[row,col]);snaps.append(dict(node=name,resolution=res,requested_u=q[0],requested_v=q[1],grid_u=x0+col*res,grid_v=y1-row*res,snap=shift))
    names=list(lookup);dist,pred=dijkstra(graph,indices=[lookup[n] for n in names],return_predecessors=True,directed=False)
    pairs={};paths={}
    for i,a in enumerate(names):
      for b in names[i+1:]:
        val=float(dist[i,lookup[b]])
        if not math.isfinite(val):continue
        pairs[(a,b)]=val;cur=lookup[b];seq=[]
        while cur!=lookup[a]:
            row,col=free[cur];seq.append([x0+int(col)*res,y1-int(row)*res]);cur=int(pred[i,cur]);assert cur>=0
        row,col=free[cur];seq.append([x0+int(col)*res,y1-int(row)*res]);paths[(a,b)]=seq[::-1]
    if save_mask:Image.fromarray((mask*255).astype(np.uint8)).save(HERE/f'B4_expanded_mask_{res}.png')
    return dict(pairs=pairs,paths=paths,snaps=snaps,bounds=(x0,y0,x1,y1))

def cached_b5(res):
    p=GEO/('floor_route_paths_fine.json' if res==.125 else 'floor_route_paths.json')
    paths={tuple(k.split('|')):seq for k,seq in json.loads(p.read_text(encoding='utf8'))['B5'].items()}
    return dict(pairs={key:float(np.linalg.norm(np.diff(np.array(seq),axis=0),axis=1).sum()) for key,seq in paths.items()},paths=paths)

def solve(floors,origin,profile,outage):
    adj={n:[] for n in PORTS}
    for level,r in floors.items():
      for (a,b),val in r['pairs'].items():
        adj[a].append((b,val,0.,0,'WALK'));adj[b].append((a,val,0.,0,'WALK'))
    for a,b,kind,serial in base.VERTICAL:
        if serial in outage or (kind=='STAIR' and profile!='STAIRS_ALLOWED'):continue
        run=float(np.linalg.norm(np.array(PORTS[a][1])-np.array(PORTS[b][1]))) if kind=='STAIR' else 0.
        rise=4.4 if kind=='STAIR' else 0.;el=int(kind=='EL')
        adj[a].append((b,run,rise,el,serial));adj[b].append((a,run,rise,el,serial))
    cost={origin:(0.,0.,0)};prev={};q=[(0.,0.,0,origin)]
    while q:
        d,h,e,a=heapq.heappop(q)
        if cost.get(a)!=(d,h,e):continue
        for b,w,dh,de,edge in adj[a]:
            nc=(d+w,h+dh,e+de)
            if nc<cost.get(b,(math.inf,)*3):cost[b]=nc;prev[b]=(a,edge);heapq.heappush(q,(*nc,b))
    names=list(PORTS);idx={n:i for i,n in enumerate(names)};fw=np.full((len(names),len(names)),np.inf);np.fill_diagonal(fw,0)
    for a,edges in adj.items():
      for b,d,*_ in edges:fw[idx[a],idx[b]]=min(fw[idx[a],idx[b]],d)
    for k in range(len(names)):fw=np.minimum(fw,fw[:,k,None]+fw[None,k,:])
    rows=[];paths={}
    for target in [f'{p}{i}' for p in ['M','H'] for i in range(1,5)]:
        reach=target in cost;path=[]
        if reach:
            u=target
            while u!=origin:
                a,e=prev[u];path.append((a,u,e));u=a
            path=path[::-1]
        v=fw[idx[origin],idx[target]];assert math.isfinite(v)==reach
        if reach:assert abs(v-cost[target][0])<1e-7
        rows.append(dict(origin=origin,target=target,profile=profile,outage='+'.join(outage) or 'NONE',
            reachable=reach,horizontal_self_propelled_model_m=round(cost[target][0],3) if reach else '',
            stair_rise_m=cost[target][1] if reach else '',el_boardings=cost[target][2] if reach else '',
            facilities=';'.join(e for a,b,e in path if e!='WALK'),
            scope='B4 model tread-bottom-plus1 approach to B5 fixed marking point only; not whole transfer',
            actual_distance_measured=False))
        paths[target]=path
    return rows,paths

def draw_path(floors,origin,target,path):
    # Visual evidence of the chosen route; background is the same floor triangles.
    W,H=1500,1100;scale=7.;x0,y0,x1,y1=(-30,-65,150,45)
    im=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(im);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17)
    def xy(q):return (55+(q[0]-x0)*scale,60+(y1-q[1])*scale)
    for level,parts,color in [('B4',[85,86,87],'#e7edf1'),('B5',[112],'#f2e9db')]:
        for part in parts:
            p=Z[f'{level}__{part}_points'];f=Z[f'{level}__{part}_faces']
            for t in p[f]:d.polygon([xy(R@v[:2]) for v in t],fill=color)
    for a,b,e in path:
        level=PORTS[a][0]
        if e=='WALK':
            seq=floors[level]['paths'].get((a,b))
            if seq is None:seq=floors[level]['paths'][(b,a)][::-1]
            d.line([xy(q) for q in seq],fill='#c74825',width=4)
        else:d.line([xy(PORTS[a][1]),xy(PORTS[b][1])],fill='#5841ad',width=5)
    for n in [origin,target]:
        x,y=xy(PORTS[n][1]);d.ellipse((x-5,y-5,x+5,y+5),fill='black');d.text((x+8,y-10),n,font=font,fill='black')
    d.text((55,20),origin+' -> '+target+' | checked local model geometry, no full-transfer or current-route claim',font=font,fill='black')
    im.save(HERE/f'path_{origin}_{target}.png')

def main():
    landing=landings();origins=[r['node'] for r in landing];runs={};snaprows=[];equiv=0
    for res in [.25,.125]:
        floors={'B4':build_b4(res),'B5':cached_b5(res)};rows=[]
        for origin in origins+['J2']:
          for profile in ['STAIRS_ALLOWED','EL_REQUIRED','ES_ALLOWED_NO_STAIRS']:
           for outage in [[],['0103-813'],['0103-814'],['0103-813','0103-814']]:
            rr,paths=solve(floors,origin,profile,outage);rows.extend(rr)
            if res==.125 and origin in [origins[0],origins[2]] and profile=='EL_REQUIRED' and not outage:
                draw_path(floors,origin,'M2',paths['M2'])
        runs[res]=rows;snaprows.extend(floors['B4']['snaps'])
        csvwrite(f'local_extension_results_{res}.csv',rows)
        # The new extent must reproduce all original J2 scenarios at same grid.
        old=list(csv.DictReader((GEO/f'route_results_grid_{res}.csv').open(encoding='utf-8-sig')))
        for r in rows:
            if r['origin']!='J2' or r['profile']=='ES_ALLOWED_NO_STAIRS':continue
            op='ALL_MODES' if r['profile']=='STAIRS_ALLOWED' else 'NO_STAIRS'
            match=next(x for x in old if x['profile']==op and x['outage']==r['outage'] and x['target']==r['target'])
            assert r['reachable']==(match['reachable']=='True')
            if r['reachable']:assert abs(r['horizontal_self_propelled_model_m']-float(match['walk_m']))<.002,(res,r,match)
            equiv+=1
        print('resolution',res,'rows',len(rows),'completed',flush=True)
    csvwrite('local_extension_node_snaps.csv',snaprows)
    comparison=[];changes=[]
    for r in runs[.125]:
        if r['origin']=='J2':continue
        same=lambda x:all(x[k]==r[k] for k in ['origin','target','profile','outage'])
        coarse=next(x for x in runs[.25] if same(x));assert coarse['reachable']==r['reachable']
        if r['reachable']:changes.append(abs(r['horizontal_self_propelled_model_m']-coarse['horizontal_self_propelled_model_m']))
        if r['outage']!='NONE':continue
        if r['profile']!='STAIRS_ALLOWED':continue
        no=next(x for x in runs[.125] if x['origin']==r['origin'] and x['target']==r['target'] and x['profile']=='EL_REQUIRED' and x['outage']=='NONE')
        es=next(x for x in runs[.125] if x['origin']==r['origin'] and x['target']==r['target'] and x['profile']=='ES_ALLOWED_NO_STAIRS' and x['outage']=='NONE')
        assert no['horizontal_self_propelled_model_m']==es['horizontal_self_propelled_model_m']
        comparison.append(dict(origin=r['origin'],target=r['target'],stairs_allowed=r['horizontal_self_propelled_model_m'],
            el_required=no['horizontal_self_propelled_model_m'],es_allowed_no_stairs=es['horizontal_self_propelled_model_m'],
            extra_no_stairs=round(no['horizontal_self_propelled_model_m']-r['horizontal_self_propelled_model_m'],3),
            scope='local model section only; B4-B5 has no ES; not a full transfer detour'))
    csvwrite('local_extension_comparison.csv',comparison)
    outage_deltas=[]
    for r in runs[.125]:
        if r['origin']=='J2' or r['outage']=='NONE':continue
        def match(rows,outage):
            return next(x for x in rows if all(x[k]==r[k] for k in ['origin','target','profile']) and x['outage']==outage)
        baseline=match(runs[.125],'NONE');coarse=match(runs[.25],r['outage']);coarse_base=match(runs[.25],'NONE')
        delta=round(r['horizontal_self_propelled_model_m']-baseline['horizontal_self_propelled_model_m'],3) if r['reachable'] else ''
        coarse_delta=round(coarse['horizontal_self_propelled_model_m']-coarse_base['horizontal_self_propelled_model_m'],3) if coarse['reachable'] else ''
        if r['reachable']:assert delta>=-.001
        outage_deltas.append(dict(origin=r['origin'],target=r['target'],profile=r['profile'],outage=r['outage'],
            normal_model_m=baseline['horizontal_self_propelled_model_m'],outage_model_m=r['horizontal_self_propelled_model_m'],
            outage_reachable=r['reachable'],additional_model_m=delta,additional_model_m_grid025=coarse_delta,
            interpretation='same local OD; model estimate, not full transfer or observed distance' if r['reachable'] else 'local unreachable, not zero distance or whole station impossibility'))
    csvwrite('local_extension_outage_deltas.csv',outage_deltas)
    check=dict(component_count=4,current_ES_units_individually_mapped=False,origins=origins,
        rows_each_resolution=len(runs[.125]),old_J2_scenarios_reproduced=equiv,
        resolutions=[.25,.125],reachability_resolution_agreement=True,
        max_distance_change_between_resolutions=max(changes),max_new_origin_snap=max(r['snap'] for r in snaprows if r['node'].startswith('TREAD')),
        three_profiles_distinct_whole_transfer=False,reason='No B4-to-B5 ES; EL_REQUIRED and ES_ALLOWED_NO_STAIRS use same two EL',
        metric='horizontal self-propelled corridor plus stair plan distance; ES ride and EL cabin movement excluded',
        local_outage_delta_rows=len(outage_deltas),
        max_finite_local_outage_extra_model_m=max(r['additional_model_m'] for r in outage_deltas if r['additional_model_m']!=''),
        actual_full_transfer_distance_computed=False,full_transfer_outage_detour_computed=False,
        mesh_sha256=hashlib.sha256((GEO/'mesh_arrays.npz').read_bytes()).hexdigest())
    jsave('local_extension_checks.json',check);print(json.dumps(check,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
