"""Verify40-world key cases against manual graph transcription + DFS.

Only function definitions from our independent20-world audit are reused;
the production checker and its helpers are never executed/imported.
"""
import ast
import csv
import hashlib
import json
from pathlib import Path

P=Path(__file__).resolve().parent
manual_path=P/'audit_access_independent.py'
manual_text=manual_path.read_text(encoding='utf-8')
tree=ast.parse(manual_text)
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('physical_edges','path')]
namespace={}
exec(compile(ast.Module(body=functions,type_ignores=[]),str(manual_path),'exec'),namespace)
physical_edges,path=namespace['physical_edges'],namespace['path']

def read_csv(name):
    with (P/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

actual={(r['world'],r['profile'],r['outage']):r for r in read_csv('expanded_access_maintenance_by_world.csv')}
actual_envelope={(r['profile'],r['outage']):r for r in read_csv('expanded_access_maintenance_envelope.csv')}
published=json.loads((P/'expanded_access_maintenance_checks.json').read_text(encoding='utf-8'))
bases=[('CORE_ONLY',False,False,True)]
bases += [(f'K_LINK_EL{int(el)}_ES8_{direction}',True,el,direction=='UP')
          for el in (False,True) for direction in ('UP','DOWN')]
forward=[(a,b) for a in ('L2_SANG','L2_HAN') for b in ('L5_HA','L5_MA')]
ods=forward+[(b,a) for a,b in forward]
outages=[(),('2133-670',),('0003-466','1809-217'),('1800-566','2133-670')]
rows,discrepancies,witnesses=[],[],[]
failed_EL1_link_leak=0
for base,korail,korail_el,es8_up in bases:
    for sang in (False,True):
        for han in (False,True):
            for b2_access in (False,True):
                world=f'{base}_SANG_ACCESS{int(sang)}_HAN_ACCESS{int(han)}_EL1_B2_SANG_ACCESS{int(b2_access)}'
                raw=physical_edges(korail,korail_el,es8_up)
                if b2_access:
                    raw.extend([('L2_SANG','B4','EL','2133-670'),('B4','L2_SANG','EL','2133-670')])
                off=set()
                if not sang:off.update(('1800-564','1800-565'))
                if not han:off.update(('1800-566','1800-567'))
                for profile in ('EL_ONLY','ES_ALLOWED_NO_STAIRS'):
                    for failed in outages:
                        es=[e for e in raw if e[3] not in off and e[3] not in failed
                            and (profile!='EL_ONLY' or e[2]!='ES')]
                        if '2133-670' in failed:
                            failed_EL1_link_leak += sum(e[3]=='2133-670' for e in es)
                        routes={f'{a}->{b}':path(es,a,b) for a,b in ods}
                        lost=[od for od,route in routes.items() if route is None]
                        label=';'.join(failed) or 'NONE'
                        r=dict(world=world,el1_b2_sang_access=b2_access,profile=profile,outage=label,
                               lost=len(lost),lost_OD=lost)
                        rows.append(r)
                        observed=actual[(world,profile,label)]
                        if len(lost)!=int(observed['lost_equal_weight_OD']) or len(lost)!=int(observed['newly_lost_from_same_world_baseline']):
                            discrepancies.append({'independent':r,'original':observed})
                        if base=='CORE_ONLY' and not sang and not han and label in ('2133-670','0003-466;1809-217'):
                            witnesses.append({**r,'routes':routes})

envelopes=[]
for profile in ('EL_ONLY','ES_ALLOWED_NO_STAIRS'):
    for failed in outages[1:]:
        label=';'.join(failed)
        selected=[r for r in rows if r['profile']==profile and r['outage']==label]
        lo,hi=min(r['lost'] for r in selected),max(r['lost'] for r in selected)
        r=dict(profile=profile,outage=label,min_lost_OD=lo,max_lost_OD=hi,total_OD=8)
        envelopes.append(r)
        observed=actual_envelope[(profile,label)]
        if (lo,hi)!=(int(observed['min_lost_OD']),int(observed['max_lost_OD'])):
            discrepancies.append({'independent_envelope':r,'original':observed})
        if r not in published['key_results']:
            discrepancies.append({'independent_envelope':r,'not_found_in_checks_json':True})

pair_summary=[]
for profile in ('EL_ONLY','ES_ALLOWED_NO_STAIRS'):
    for b2_access in (False,True):
        selected=[r for r in rows if r['profile']==profile and r['outage']=='0003-466;1809-217'
                  and r['el1_b2_sang_access']==b2_access]
        pair_summary.append({'profile':profile,'el1_b2_sang_access':b2_access,'world_count':len(selected),
                             'distinct_lost_counts':sorted(set(r['lost'] for r in selected))})

result={
    'audit_date':'2026-10-22',
    'method':'Independently manually transcribed literal edges and DFS route witnesses, reused only function definitions from the independent audit. Production checker/helper not imported or executed.',
    'manual_edge_source_sha256':hashlib.sha256(manual_text.encode('utf-8')).hexdigest(),
    'checked_worlds':40,'checked_profiles':2,'checked_outage_cases_including_baseline':4,
    'checked_summary_rows':len(rows),'checked_OD_results':len(rows)*8,
    'discrepancies':discrepancies,'envelope_results':envelopes,
    'baseline_all8_reachable':all(r['lost']==0 for r in rows if r['outage']=='NONE'),
    'EL1_failure_removes_all_edges_with_same_serial':failed_EL1_link_leak==0,
    'SANG_pair_conditional_summary':pair_summary,
    'selected_witness_cases':witnesses,
    'direct_reasoning':[
        'B2 access OFF: EL0003-466 and ES1809-217 still exhaust the modeled outgoing links from L2_SANG, giving2 lost forward OD pairs under ES_ALLOWED_NO_STAIRS and4 involving SANG under EL_ONLY.',
        'B2 access ON: the same failed pair leaves EL2133-670 available. SANG->B4 through its hypothetical B2 access, followed by EL0103-813 or0103-814, reaches both Line5 destinations. Reverse paths also exist. Both profiles therefore lose0 OD pairs in all20 B2-enabled worlds.',
        'An EL2133-670 failure removes the B1-B4 connection and both hypothetical SANG-B4 directions together because they use the same serial. New B2 access therefore cannot rescue this outage; its ES-profile envelope remains0-8 and EL_ONLY remains8.',
        'The20-world pair result was conditional on a smaller graph. The40-world0-2/0-4 envelope supersedes any statement that the pair is always a physical station cut.'
    ],
    'interpretation_limits':[
        'Official audio-guide installation text supports a B2 position in front of Line5 elevator1. It does not establish stair-free and permitted access from L2_SANG, the exact elevator serial, live passenger-door operation, or fare-zone continuity.',
        'The new aggregate SANG-B4 edge represents an unverified walking approach plus elevator use. It is a reachability hypothesis, not a measured or reconstructed corridor.',
        'Internal B1 connections, other elevator approach steps, ramps/lifts and unmapped gates remain assumptions. These40 worlds do not exhaust every physically plausible current station network.',
        'No travel distance, outage detour distance, boarding-count cost, waiting time or failure probability is verified here.',
        'Eight refers to equal-weight directed platform-pair OD types, not passengers. The range across hypotheses is not a confidence interval.'
    ]
}
(P/'expanded_access_independent_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'summary_rows':len(rows),'OD_checks':len(rows)*8,'discrepancies':len(discrepancies),
                  'same_serial_outage_filter_ok':failed_EL1_link_leak==0,'pair_summary':pair_summary},ensure_ascii=False))
