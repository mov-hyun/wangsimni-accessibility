"""Extend conditional maintenance tests with unverified long-ES access connectors.

The serial is operational only if BOTH its physical machine and its approach are
available. A disabled access connector is not a broken machine. This is a coarse
scenario envelope, not a reconstruction or certification of current station paths.
No metre lengths or probabilities are assigned to unknown connectors.
"""
from pathlib import Path
from itertools import combinations,product
from collections import deque
import csv,json,sys
P=Path(__file__).resolve().parent
INCLUDE_B2='--el1-b2-access' in sys.argv
PREFIX='expanded_' if INCLUDE_B2 else ''
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
    with (P/(PREFIX+name)).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
core=read(P.parent/'geometry/core_topology_edges.csv')
cand=read(P.parent/'upper_check/candidate_korail_edges.csv')
kel=read(P.parent/'upper_check/korail_el5_candidate_edges.csv')
base={'CORE_ONLY':core}
for el,d in product([False,True],['UP','DOWN']):
    a,b=('K_CENTRAL','K_UPPER') if d=='UP' else ('K_UPPER','K_CENTRAL')
    base[f'K_LINK_EL{int(el)}_ES8_{d}']=core+cand+[dict(start=a,end=b,kind='ES',serial='1800-364')]+(kel if el else [])
ids=sorted({e['serial'] for es in base.values() for e in es if e['kind'] in ['EL','ES']})
outages=[()]+[(s,) for s in ids]+list(combinations(ids,2))
for s in [('1800-560','1800-561','1800-562','1800-563'),('1800-364','1800-365','1800-366','1800-371'),('2133-670','1800-364','1800-365','1800-366','1800-371'),('2133-670','1800-560','1800-561','1800-562','1800-563')]:
    outages.append(tuple(sorted(s)))
ods=[(a,b) for a in ['L2_SANG','L2_HAN'] for b in ['L5_HA','L5_MA']]
ods += [(b,a) for a,b in ods.copy()]
rows=[];minimal=[];mismatch=0;checks=0
for (base_name,base_raw),sang,han,b2 in product(base.items(),[False,True],[False,True],[False,True] if INCLUDE_B2 else [False]):
    # Optional hypothesis: Line2 Sang platform can reach the B2 EL1 door
    # without stairs or an inaccessible gate. The same physical EL1 serial
    # disables BOTH its B1 and hypothetical B2 access on failure.
    raw=base_raw+[dict(start=a,end=b,kind='EL',serial='2133-670') for a,b in [('L2_SANG','B4'),('B4','L2_SANG')]] if b2 else base_raw
    blocked=({'1800-564','1800-565'} if not sang else set())|({'1800-566','1800-567'} if not han else set())
    edges=[e for e in raw if e['serial'] not in blocked]
    world=f'{base_name}_SANG_ACCESS{int(sang)}_HAN_ACCESS{int(han)}'+(f'_EL1_B2_SANG_ACCESS{int(b2)}' if INCLUDE_B2 else '')
    for profile in ['EL_ONLY','ES_ALLOWED_NO_STAIRS']:
        cache={}
        for failed in outages:
            es=[e for e in edges if e['serial'] not in failed and (profile!='EL_ONLY' or e['kind']!='ES')]
            nodes=sorted({n for e in raw for n in (e['start'],e['end'])});ix={n:i for i,n in enumerate(nodes)}
            d=[[a==b for b in nodes] for a in nodes];adj={a:[] for a in nodes}
            for e in es:d[ix[e['start']]][ix[e['end']]]=True;adj[e['start']].append(e['end'])
            for k in range(len(nodes)):
                for i in range(len(nodes)):
                    if d[i][k]:
                        for j in range(len(nodes)):d[i][j] |= d[k][j]
            reach={}
            for a,b in ods:
                seen={a};q=deque([a])
                while q:
                    for v in adj[q.popleft()]:
                        if v not in seen:seen.add(v);q.append(v)
                yes=b in seen;checks+=1;mismatch+=int(yes!=d[ix[a]][ix[b]])
                reach[(a,b)]=yes
            cache[failed]=reach
            rows.append(dict(world=world,base_world=base_name,sang_access=sang,han_access=han,el1_b2_sang_access=b2,
                profile=profile,outage=';'.join(failed) or 'NONE',lost_equal_weight_OD=sum(not v for v in reach.values()),
                newly_lost_from_same_world_baseline=sum(cache[()].get(od,False) and not v for od,v in reach.items()),total_OD=8))
        for pair in combinations(ids,2):
            loss=[f'{a}->{b}' for (a,b),yes in cache[pair].items() if not yes and cache[(pair[0],)][(a,b)] and cache[(pair[1],)][(a,b)]]
            if loss:minimal.append(dict(world=world,profile=profile,equipment_a=pair[0],equipment_b=pair[1],affected_OD=';'.join(loss),newly_disconnected_OD=len(loss)))
write('access_maintenance_by_world.csv',rows);write('access_minimal_pairs.csv',minimal)
env=[]
for profile,failed in product(['EL_ONLY','ES_ALLOWED_NO_STAIRS'],outages):
    key=';'.join(failed) or 'NONE';rs=[r for r in rows if r['profile']==profile and r['outage']==key]
    env.append(dict(profile=profile,outage=key,min_lost_OD=min(r['lost_equal_weight_OD'] for r in rs),max_lost_OD=max(r['lost_equal_weight_OD'] for r in rs),total_OD=8))
write('access_maintenance_envelope.csv',env)
key_results=[r for r in env if r['outage'] in ['2133-670','0003-466;1809-217','1800-566;2133-670']]
assert mismatch==0
assert all(r['lost_equal_weight_OD']==0 for r in rows if r['outage']=='NONE')
assert len([r for r in minimal if r['profile']=='ES_ALLOWED_NO_STAIRS' and r['equipment_a']=='0003-466' and r['equipment_b']=='1809-217'])==20
result=dict(worlds=40 if INCLUDE_B2 else 20,physical_equipment=len(ids),outage_sets=len(outages),summary_rows=len(rows),independent_BFS_vs_Warshall=checks,mismatches=mismatch,
    key_results=key_results,model_validity='UNVERIFIED_APPROACH_CONNECTORS_EXPLICITLY_GATED',
    findings_status='Conditional graph only. Additional unmapped paths/lifts and lower-hall internal access can change actual results. B2-enabled worlds additionally require stair-free and permitted access from L2_SANG to the B2 EL1 door; the new official beacon location evidence alone does not establish this.',
    supersedes='20-world envelope for conclusions that omit potential EL1 B2 access' if INCLUDE_B2 else '5-world maintenance envelope for any statement that ignores long-ES access uncertainty',
    distance_computed=False,probability_computed=False,passenger_weighted=False)
(P/(PREFIX+'access_maintenance_checks.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
