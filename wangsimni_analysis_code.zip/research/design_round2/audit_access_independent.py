"""Independent spot/envelope audit: manually transcribed edges, DFS witnesses.

Does not import or run the production sensitivity checker or its reachability helper.
"""
import csv
import json
from pathlib import Path

P = Path(__file__).resolve().parent

def physical_edges(korail, korail_el, es8_up):
    edges = []
    for a, b, serial in [
        ("L2_SANG", "B1", "0003-466"),
        ("L2_HAN", "B1", "0068-689"),
        ("B1", "B4", "2133-670"),
        ("B4", "L5_HA", "0103-813"),
        ("B4", "L5_MA", "0103-814"),
    ]:
        edges += [(a,b,"EL",serial),(b,a,"EL",serial)]
    for a,b,serial in [
        ("B1","L2_SANG","1809-216"),("L2_SANG","B1","1809-217"),
        ("B1","L2_HAN","1809-218"),("L2_HAN","B1","1809-219"),
        ("B1","L2_HAN","1808-501"),("L2_HAN","B1","1808-502"),
        ("B4","L2_SANG","1800-564"),("B4","L2_SANG","1800-565"),
        ("L2_HAN","B4","1800-566"),("B4","L2_HAN","1800-567"),
    ]:
        edges.append((a,b,"ES",serial))
    if korail:
        edges += [("B1","K_UPPER","WALK","CANDIDATE_STEP_FREE_LINK"),
                  ("K_UPPER","B1","WALK","CANDIDATE_STEP_FREE_LINK")]
        for a,b,serial in [
            ("K_UPPER","K_CENTRAL","1800-371"),("K_UPPER","K_CENTRAL","1800-366"),
            ("K_CENTRAL","K_UPPER","1800-365"),("K_CENTRAL","B4","1800-560"),
            ("K_CENTRAL","B4","1800-561"),("B4","K_CENTRAL","1800-562"),
            ("B4","K_CENTRAL","1800-563"),
        ]:
            edges.append((a,b,"ES",serial))
        a,b=("K_CENTRAL","K_UPPER") if es8_up else ("K_UPPER","K_CENTRAL")
        edges.append((a,b,"ES","1800-364"))
        if korail_el:
            edges += [("K_UPPER","K_CENTRAL","EL","0042-306"),
                      ("K_CENTRAL","K_UPPER","EL","0042-306")]
    return edges

def path(edges, start, target):
    stack = [(start, [])]
    seen = set()
    while stack:
        node, route = stack.pop()
        if node == target:
            return route
        if node in seen:
            continue
        seen.add(node)
        for a,b,kind,serial in edges:
            if a == node and b not in seen:
                stack.append((b, route+[{"from":a,"to":b,"kind":kind,"serial":serial}]))
    return None

forward = [(a,b) for a in ("L2_SANG","L2_HAN") for b in ("L5_HA","L5_MA")]
ods = forward + [(b,a) for a,b in forward]
outages = [(), ("2133-670",), ("0003-466","1809-217"), ("1800-566","2133-670")]
with (P/"access_maintenance_by_world.csv").open(encoding="utf-8-sig",newline="") as f:
    actual = {(r["world"],r["profile"],r["outage"]):r for r in csv.DictReader(f)}
with (P/"access_maintenance_envelope.csv").open(encoding="utf-8-sig",newline="") as f:
    actual_envelope = {(r["profile"],r["outage"]):r for r in csv.DictReader(f)}
base_worlds = [("CORE_ONLY",False,False,True)]
base_worlds += [(f"K_LINK_EL{int(el)}_ES8_{direction}",True,el,direction=="UP")
               for el in (False,True) for direction in ("UP","DOWN")]
rows, discrepancies, witnesses = [], [], []
for name,korail,korail_el,es8_up in base_worlds:
    for sang in (False,True):
        for han in (False,True):
            world=f"{name}_SANG_ACCESS{int(sang)}_HAN_ACCESS{int(han)}"
            inaccessible = set()
            if not sang: inaccessible.update(("1800-564","1800-565"))
            if not han: inaccessible.update(("1800-566","1800-567"))
            for profile in ("EL_ONLY","ES_ALLOWED_NO_STAIRS"):
                for failed in outages:
                    edges = [e for e in physical_edges(korail,korail_el,es8_up)
                             if e[3] not in inaccessible and e[3] not in failed
                             and (profile != "EL_ONLY" or e[2] != "ES")]
                    routes = {f"{a}->{b}":path(edges,a,b) for a,b in ods}
                    lost = [od for od,route in routes.items() if route is None]
                    label = ";".join(failed) or "NONE"
                    row = dict(world=world,profile=profile,outage=label,lost=len(lost),lost_OD=lost)
                    rows.append(row)
                    expected = actual[(world,profile,label)]
                    if len(lost) != int(expected["lost_equal_weight_OD"]) or len(lost) != int(expected["newly_lost_from_same_world_baseline"]):
                        discrepancies.append({"independent":row,"original":expected})
                    if profile=="ES_ALLOWED_NO_STAIRS" and label=="2133-670" and (
                        (name=="CORE_ONLY" and ((not sang and not han) or (not sang and han)))
                        or (name=="K_LINK_EL0_ES8_UP" and not sang and not han)):
                        witnesses.append({**row,"routes":routes})

envelopes=[]
for profile in ("EL_ONLY","ES_ALLOWED_NO_STAIRS"):
    for failed in outages[1:]:
        label=";".join(failed)
        selected=[r for r in rows if r['profile']==profile and r['outage']==label]
        lo,hi=min(r['lost'] for r in selected),max(r['lost'] for r in selected)
        expected=actual_envelope[(profile,label)]
        if (lo,hi)!=(int(expected['min_lost_OD']),int(expected['max_lost_OD'])):
            discrepancies.append({'profile':profile,'outage':label,'independent':[lo,hi],'original':expected})
        envelopes.append({'profile':profile,'outage':label,'min_lost_OD':lo,'max_lost_OD':hi})

pair_rows=[r for r in rows if r['profile']=='ES_ALLOWED_NO_STAIRS' and r['outage']=='0003-466;1809-217']
result = {
    'audit_date':'2026-10-22',
    'method':'Manual edge transcription from inspected literal CSV rows, followed by independent depth-first path enumeration with explicit route witnesses. Original checker/helper not imported or rerun.',
    'checked_worlds':20,'checked_profiles':2,'checked_outage_cases_including_baseline':4,
    'checked_summary_rows':len(rows),'checked_OD_results':len(rows)*8,
    'discrepancies':discrepancies,'envelope_results':envelopes,
    'baseline_all_8_reachable_in_each_world_profile':all(r['lost']==0 for r in rows if r['outage']=='NONE'),
    'SANG_pair_all20_loses_exactly_SANG_to_both_L5':len(pair_rows)==20 and all(set(r['lost_OD'])=={'L2_SANG->L5_HA','L2_SANG->L5_MA'} for r in pair_rows),
    'EL1_single_ES_profile_core_detail':[r for r in rows if r['profile']=='ES_ALLOWED_NO_STAIRS' and r['outage']=='2133-670' and r['world'].startswith('CORE_ONLY')],
    'selected_witness_cases':witnesses,
    'direct_reasoning':[
        'Without either access family and with EL1 failed, CORE has no edge across the B1/platform-side and B4/Line5-side partition; all8 directed OD pairs fail.',
        'With HAN access enabled, ES1800-566/567 form the up/down bridge through L2_HAN, and EL0068-689 connects L2_HAN with B1; therefore EL1 alone can cause0 losses even when SANG access is disabled.',
        'In Korail-linked worlds, the conditional B1-K_UPPER walkway plus existing down/up Korail ES and long ES give a bridge without either direct long-ES approach family;0loss is conditional on these assumed connectors.',
        'Removing EL0003-466 and ES1809-217 removes every outgoing edge from L2_SANG in all20 worlds. No Korail or access flag adds an alternative edge at that origin; exactly its two forward Line5 destinations are lost in the literal graph.'
    ],
    'interpretation_limits':[
        'Access flags gate aggregate machine edges; they do not reconstruct actual stair, ramp, platform entrance or elevator-door access.',
        'User confirmed the stairs in photo891 still exist. This establishes the photographed obstacle, not the absence of a separate ramp or alternative path.',
        'Unknown internal B1 connections, EL approach level differences, unmapped lifts/ramps and paid-zone connections may change actual reachability.',
        'All worlds assume the core elevator access is usable. Baseline8/8 is a model assumption result, not an accessibility certification.',
        'The0-8 range is across specified assumptions, not a failure probability, confidence interval, passenger count, travel distance or detour-distance estimate.',
        'The denominator8 is equal-weight directed platform-pair OD types; no passenger weighting.'
    ]
}
(P/'access_independent_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'summary_rows':len(rows),'OD_checks':len(rows)*8,'discrepancies':len(discrepancies),'envelopes':envelopes},ensure_ascii=False))
